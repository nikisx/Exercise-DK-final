﻿namespace Exercise_DK.Entities
{
	public class BetModel
	{
        public string Id  { get; set; }
        public DateTime PlacementDate { get; set; }
        public decimal Stake { get; set; }
    }
}
